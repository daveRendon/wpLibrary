Application demonstrates additional jQM theme for Windows Phone features when running under Cordova framework. 
https://github.com/cordova

Please note, that www folder is empty because we reference to remote server where all content (html, js, css) is stored. Please see CordovaView.StartPageUri for more details.


Plugins


The following Cordova extra plugins are used to unlock native UI related functionality (under App\Plugins folder):
1.	PhoneTheme.cs � to detect the system colors selected on the device.
2.	DateTimePicker.cs � to provide the native ui for date/time selection operations.


Build instructions

Silverlight for Windows Phone Toolkit is required to build the application
http://silverlight.codeplex.com/releases/view/71550#DownloadId=270984

License

Licensed under the Apache License, Version 2.0 (the "License")

http://www.apache.org/licenses/LICENSE-2.0 

Copyright (c) 2011-2012, Sergey Grebnov

